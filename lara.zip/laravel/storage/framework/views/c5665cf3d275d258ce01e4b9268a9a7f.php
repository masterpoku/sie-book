<?php $__env->startSection('content'); ?>

<?php if(session('message')): ?>
<div class="alert <?php echo e(session('message.type') === 'success' ? 'alert-success' : 'alert-danger'); ?>">
    <?php echo e(session('message.content')); ?>

</div>
<?php endif; ?>

<div class="card">
    <h5 class="card-header">Daftar Submateri</h5>
    <div class="card-body">
        <!-- Tombol Tambah Submateri -->
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addSubmateriModal">
            Tambah Submateri
        </button>
    </div>

    <div class="table-responsive text-nowrap mt-4">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Relasi materi</th>
                    <th>Nama Submateri</th>
                    <th>Deskripsi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $submateris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
            <td><?php echo e($item->id); ?></td>
            <td><?php echo e($item->materi->mapel ?? 'Tidak ditemukan'); ?>.<?php echo e($item->materi->kelas ?? ''); ?>.<?php echo e($item->materi->name ?? ''); ?></td>
            <td><?php echo e($item->name); ?></td>
            <td>
                <!-- Tombol Tampilkan Deskripsi -->
                <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#viewDescriptionModal<?php echo e($item->id); ?>">
                    Lihat Deskripsi
                </button>
            </td>
            <td>
                <!-- Tombol Edit -->
                <button type="button" class="btn btn-sm btn-warning" 
                    data-bs-toggle="modal" 
                    data-bs-target="#editSubmateriModal<?php echo e($item->id); ?>">
                    Edit
                </button>

                <!-- Tombol Hapus -->
                <form action="<?php echo e(route('submateris.destroy', $item->id)); ?>" method="POST" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus?')">Hapus</button>
                </form>
            </td>
        </tr>

              <!-- Modal Tampilkan Deskripsi -->
                <div class="modal fade" id="viewDescriptionModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="viewDescriptionLabel<?php echo e($item->id); ?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="viewDescriptionLabel<?php echo e($item->id); ?>">Deskripsi Submateri</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body" style="max-height: 400px; overflow-y: auto;">
                                <?php echo $item->description ?? 'Tidak ada deskripsi.'; ?>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /Modal Tampilkan Deskripsi -->

                    <!-- Modal Edit Submateri -->
                    <div class="modal fade" id="editSubmateriModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="editSubmateriLabel<?php echo e($item->id); ?>" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editSubmateriLabel<?php echo e($item->id); ?>">Edit Submateri</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form action="<?php echo e(route('submateris.update', $item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label for="materi_id" class="form-label">Materi</label>
                                            <select class="form-control" id="materi_id" name="materi_id" required>
                                                <?php $__currentLoopData = $materis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($materi->id); ?>" <?php echo e($item->materi_id == $materi->id ? 'selected' : ''); ?>>
                                                        <?php echo e($materi->mapel); ?>.<?php echo e($materi->kelas); ?>.<?php echo e($materi->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                     
                                        <div class="mb-3">
                                            <label for="name" class="form-label">Nama Submateri</label>
                                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($item->name); ?>" required>
                                        </div>

                                        <div class="mb-3">
                                            <label for="description" class="form-label">Deskripsi</label>
                                            <div id="editQuill<?php echo e($item->id); ?>" style="height: 200px;"><?php echo $item->description ?? ''; ?></div>
                                            <textarea class="form-control d-none" id="description<?php echo e($item->id); ?>" name="description"></textarea>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                        <button type="submit" class="btn btn-success">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- /Modal Edit Submateri -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Tambah Submateri -->
<div class="modal fade" id="addSubmateriModal" tabindex="-1" aria-labelledby="addSubmateriLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addSubmateriLabel">Tambah Submateri</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('submateris.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="materi_id" class="form-label">Materi</label>
                        <select class="form-control" id="materi_id" name="materi_id" required>
                            <?php $__currentLoopData = $materis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($materi->id); ?>">   <?php echo e($materi->mapel); ?>.<?php echo e($materi->kelas); ?>.<?php echo e($materi->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="name" class="form-label">Nama Submateri</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Masukkan Nama Submateri" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Deskripsi Submateri</label>
                        <div id="quill" style="height: 200px;"></div>
                        <textarea class="form-control d-none" id="description" name="description"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- /Modal Tambah Submateri -->

<script>
   var quill = new Quill('#quill', {
    theme: 'snow',
    modules: {
        toolbar: [
            [{ header: [1, 2, false] }],
            ['bold', 'italic', 'underline'],
            ['link', 'image', 'video'],
            [{ list: 'ordered' }, { list: 'bullet' }]
        ]
    }
});

document.querySelector('form[action="<?php echo e(route('submateris.store')); ?>"]').onsubmit = function(event) {
    var description = document.querySelector('#description');
    description.value = quill.root.innerHTML;
};

<?php $__currentLoopData = $submateris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    var editQuill<?php echo e($item->id); ?> = new Quill('#editQuill<?php echo e($item->id); ?>', {
        theme: 'snow',
        modules: {
            toolbar: [
                [{ header: [1, 2, false] }],
                ['bold', 'italic', 'underline'],
                ['link', 'image', 'video'],
                [{ list: 'ordered' }, { list: 'bullet' }]
            ]
        }
    });

    document.querySelector('#editSubmateriModal<?php echo e($item->id); ?> form').onsubmit = function(event) {
        var description = document.querySelector('#description<?php echo e($item->id); ?>');
        description.value = editQuill<?php echo e($item->id); ?>.root.innerHTML;
    };
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/maswafi/css-id/azza/sie-book/resources/views/data/submateri.blade.php ENDPATH**/ ?>