<?php $__env->startSection('content'); ?>
<!-- Elemen untuk menampilkan pesan toast, awalnya tersembunyi -->
<?php if(session('message')): ?>
    <div class="bs-toast toast toast-placement-ex m-2 <?php echo e(session('message.type') === 'success' ? 'bg-success' : 'bg-danger'); ?>" id="modalMessageToast" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="2000">
        <div class="toast-header">
            <i class="bx bx-bell me-2"></i>
            <div class="me-auto fw-semibold">
                <?php echo e(session('message.type') === 'success' ? 'Sukses' : 'Error'); ?>

            </div>
            <small>just now</small>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body">
            <?php echo e(session('message.content')); ?>

        </div>
    </div>
<?php endif; ?>

<div class="row" style="margin-top: 50px;">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Daftar Kelas</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Kelas</th>
                                    <th scope="col">Total Siswa</th>
                                    <th scope="col">Daftar Siswa</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $kelasItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key + 1); ?></th>
                                    <td><?php echo e($kelasItem->kelas); ?></td>
                                    <td><?php echo e($kelasItem->siswas_count); ?></td>
                                    <td>
                                        <button type="button" class="btn btn-icon btn-primary" data-bs-toggle="modal" data-bs-target="#kelas<?php echo e($key + 1); ?>">
                                            <span class="tf-icons bx bx-list-ul"></span>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $kelasItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="kelas<?php echo e($key + 1); ?>" tabindex="-1" aria-labelledby="kelas<?php echo e($key + 1); ?>Label" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="kelas<?php echo e($key + 1); ?>Label">Daftar Siswa Kelas <?php echo e($kelasItem->kelas); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Nama</th>
                                    <th scope="col">QrCode</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $kelasItem->siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($index + 1); ?></th>
                                    <td><?php echo e($siswa->nama); ?></td>
                                    <td><img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?php echo e($siswa->unique); ?>" alt="QRCode <?php echo e($siswa->nama); ?>"></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/maswafi/css-id/azza/sie-book/resources/views/data/nilai.blade.php ENDPATH**/ ?>